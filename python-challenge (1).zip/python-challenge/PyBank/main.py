# Import modules
import os
import csv

# Set path for file
csvpath = os.path.join("Resources", "budget_data.csv")

# Open the CSV
with open(csvpath) as csvfile:
    csvreader = csv.reader(csvfile, delimiter=",")

    print("Financial Analysis")
    print("--------------------------------------------------------")

    # read the total number of months included in the dataset
    csv_header = next(csvreader)
    total_months = 0
    total_profits = 0
    previous_profits = 0
    change_profits = 0
    total_change_profits = 0
    greatest_increase = 0
    greatest_decrease = 0
    for row in csvreader:
        total_months += 1
        total_profits += int(row[1])
        if total_months == 1:
            previous_profits = int(row[1])
        else:
            change_profits = int(row[1]) - previous_profits
            total_change_profits += change_profits
            if change_profits > greatest_increase:
                greatest_increase = change_profits
                greatest_increase_month = row[0]
            if change_profits < greatest_decrease:
                greatest_decrease = change_profits
                greatest_decrease_month = row[0]
            previous_profits = int(row[1])
    print(f"Total Months: {total_months}")
    print(f"Total: ${total_profits}")
    print(f"Average Change: ${round(total_change_profits/(total_months-1),2)}")
    print(f"Greatest Increase in Profits: {greatest_increase_month} (${greatest_increase})")
    print(f"Greatest Decrease in Profits: {greatest_decrease_month} (${greatest_decrease})")

# Set variable for output file
output_file = os.path.join("analysis", "budget_data.txt")

#  Open the output file
with open(output_file, "w", newline="") as datafile:
    writer = csv.writer(datafile)

    # Write the results to the text file
    writer.writerow(["Financial Analysis"])
    writer.writerow(["--------------------------------------------------------"])
    writer.writerow([f"Total Months: {total_months}"])
    writer.writerow([f"Total: ${total_profits}"])
    writer.writerow([f"Average Change: ${round(total_change_profits/(total_months-1),2)}"])
    writer.writerow([f"Greatest Increase in Profits: {greatest_increase_month} (${greatest_increase})"])
    writer.writerow([f"Greatest Decrease in Profits: {greatest_decrease_month} (${greatest_decrease})"])

# Close the file
datafile.close()



    















