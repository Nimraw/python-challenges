# Import modules
import os
import csv

# Set path for file
csvpath = os.path.join("Resources", "election_data.csv")

# Open the CSV
with open(csvpath) as csvfile:
    csvreader = csv.reader(csvfile, delimiter=",")

    # Read the header row first (skip this step if there is now header)
    csv_header = next(csvreader)
    print("Electoral Results")
    print("-------------------------")
    
    total_votes = 0
    candidates = []
    candidate_votes = {}
    winner = ""
    winner_votes = 0

    for row in csvreader:
        total_votes += 1
        candidate = row[2]
        if candidate not in candidates:
            candidates.append(candidate)
            candidate_votes[candidate] = 0
        candidate_votes[candidate] += 1

    print(f"Total Votes: {total_votes}")
    print("-------------------------")

    for candidate in candidates:
        votes = candidate_votes[candidate]
        percentage = votes / total_votes * 100
        print(f"{candidate}: {percentage:.3f}% ({votes})")
        if votes > winner_votes:
            winner = candidate
            winner_votes = votes

    print("-------------------------")
    print(f"Winner: {winner}")
    print("-------------------------")

# Output files
output_file = os.path.join("analysis", "election_results.txt")

# Open the output file
with open(output_file, "w") as txt_file:
    
        # Write methods to print to Elections_Results_Summary 
        txt_file.write("Electoral Results")
        txt_file.write("\n")
        txt_file.write("-------------------------")
        txt_file.write("\n")
        txt_file.write(f"Total Votes: {total_votes}")
        txt_file.write("\n")
        txt_file.write("-------------------------")
        txt_file.write("\n")
        txt_file.write(f"{candidate}: {percentage:.3f}% ({votes})")
        txt_file.write("\n")
        txt_file.write("-------------------------")
        txt_file.write("\n")
        txt_file.write(f"Winner: {winner}")
        txt_file.write("\n")
        txt_file.write("-------------------------")
        txt_file.write("\n")

# Close the file
txt_file.close()





